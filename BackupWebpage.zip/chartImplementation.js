function createChart(locationData,colorPalette) {
            var chartCanvas = document.createElement('canvas');
            chartCanvas.className = 'chart-container';
            chartCanvas.width = 180;
            chartCanvas.height = 125;
            var ctx = chartCanvas.getContext('2d');
            var labels = Array.from({ length: locationData[0].co2array.split(';').length }, (_, i) => i + 1);
            var datasets = [];
            locationData.forEach(function(entry, index) {
var startDate = new Date(entry.startTime);
var formattedDate = formatDateTime(startDate);
                var entryIsoStringArray = Array.from({ length: entry.co2array.split(';').length }, (_, i) => formattedDate);
                datasets.push({
                    label: 'Entry ' + (index + 1),
                    data: entry.co2array.split(';').map(value => value !== "" ? parseFloat(value) : null),
                    borderColor: colorPalette[index],
                    borderWidth: 1,
                    hidden: false, // Initially hide the datasets
                    labels: entryIsoStringArray
                });
            });

            var chart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: labels,
        datasets: datasets
    },
    options: {
        scales: {
            y: {
                beginAtZero: false,
                min: 400,
		title: {
                    display: true,
                    text: 'CO2-Levels in ppm'
                }
            },
	    x: {
                title: {
                    display: true,
                    text: 'Minute of Measurement'
                }
            }
	   
        },
        plugins: {
            legend: {
                display: true,
                labels: {
		    font: {
                        size: 10 
                    },
                    generateLabels: function(chart) {
                        var data = chart.data;
                        if (data.labels.length && data.datasets.length) {
                            return data.datasets.map(function(dataset, i) {
				var sum = dataset.data.reduce((acc, value) => acc + value, 0);
            			var averagePPM = Math.round(sum / dataset.data.length);
                                return {
                                    text: 'Ø '+ averagePPM + 'ppm'  + ' | Starting Time: ' + dataset.labels[0],
                                    fillStyle: dataset.borderColor,
                                    hidden: dataset.hidden,
                                    index: i
                                };
                            });
                        }
                        return [];
                    }
                },
                onClick: function(event, legendItem) {
                    var index = legendItem.datasetIndex;
                    var chart = this.chart;
                    var meta = chart.getDatasetMeta(index);
                    meta.hidden = meta.hidden === null ? !chart.data.datasets[index].hidden : null;
                    chart.update();
                }
            }
        }
    }
});
            return chartCanvas;
        }