
        var currentPopup = null;	  

        // Fetch data from the provided URL with retry logic
        function fetchDataWithRetries(url, retries = 3) {
            return fetch(url)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .catch(error => {
                    console.error('Error fetching data:', error);
                    if (retries > 0) {
                        console.log(`Retrying (${retries} retries left) after 1 second...`);
                        return new Promise(resolve => setTimeout(resolve, 1000))
                            .then(() => fetchDataWithRetries(url, retries - 1));
                    } else {
                        throw new Error('Max retries exceeded');
                    }
                });
        }


        var darkGreenIcon = L.icon({
            iconUrl: 'images/dark_green_marker.png', // Path to dark green marker icon
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        var yellowIcon = L.icon({
            iconUrl: 'images/yellow_marker.png', // Path to green marker icon
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        var orangeIcon = L.icon({
            iconUrl: 'images/orange_marker.png', // Path to yellow marker icon
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        var redIcon = L.icon({
            iconUrl: 'images/red_marker.png', // Path to red marker icon
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        // Load data and add markers to the map
        fetchDataWithRetries('https://t5e1girm29.execute-api.eu-central-1.amazonaws.com/GetCO2Data')
            .then(data => {
                var locations = {};
                data.forEach(item => {
                    var measurements = JSON.parse(item.measurements);
                    measurements.forEach(locationData => {
                        var locationId = item.nrwid;
                        if (!locations[locationId]) {
                            locations[locationId] = [];
                        }
                        locations[locationId].push(locationData);
                    });
                });

                Object.values(locations).forEach(location => {
                    var markerIcon;
                    var entry = location[0];
                    if (entry.ppmavg <= 600) {
                        markerIcon = darkGreenIcon;
                    } else if (entry.ppmavg <= 800) {
                        markerIcon = yellowIcon;
                    } else if (entry.ppmavg <= 1000) {
                        markerIcon = orangeIcon;
                    } else {
                        markerIcon = redIcon;
                    }
                    var marker = L.marker([entry.lat, entry.lon], { icon: markerIcon }).addTo(map);
	            var colorPalette = generateColorPalette(location.length);
                    marker.on('click', function() {
                        var popupContent = document.createElement('div');
                        var totalAvg = 0;
                        location.forEach(entry => {
                            var entryDateTime = new Date(entry.startTime);
                            var entryIsoString = entryDateTime.toISOString();
                            totalAvg += entry.ppmavg;
                        });
                        var locationName = location[0].nwrname; // Assuming all entries have the same location name
                        var averageAvg = totalAvg / location.length;
                        var title = document.createElement('h2');
                        title.textContent = locationName + ' | Average: ' + Math.round(averageAvg) + ' ppm';
                        popupContent.insertBefore(title, popupContent.firstChild); // Insert title at the beginning
                        var chartCanvas = createChart(location,colorPalette);
                        popupContent.appendChild(chartCanvas);
                        
                        if (currentPopup) {
                            currentPopup.remove();
                        }
                        
                        currentPopup = L.popup({
                            autoPan: true,
                            autoPanPaddingTopLeft: L.point(50, 50),
                        })
                        .setLatLng(marker.getLatLng())
                        .setContent(popupContent)
                        .openOn(map);
                    });
                });
            })
            .catch(error => {
                console.error('Failed to fetch data after retries:', error);
                // Handle error, e.g., display error message to the user
            });

