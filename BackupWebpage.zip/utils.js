function formatDateTime(date) {
    var year = date.getFullYear();
    var month = (date.getMonth() + 1).toString().padStart(2, '0');
    var day = date.getDate().toString().padStart(2, '0');
    var hour = date.getHours().toString().padStart(2, '0');
    var minute = date.getMinutes().toString().padStart(2, '0');
    return `${year}-${month}-${day} ${hour}:${minute}`;
}

function generateColorPalette(length) {
    var palette = [];
    var step = 100 / (length - 1); // Calculate the step size for different shades
    for (var i = 0; i < length; i++) {
        var shade = i * step; // Calculate the shade value
        palette.push('rgb(' + shade + ',' + shade + ',' + shade + ')');
    }
    return palette;
}